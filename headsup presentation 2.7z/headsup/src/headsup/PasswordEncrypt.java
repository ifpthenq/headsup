package headsup;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;

public class PasswordEncrypt {
	private static final String ALGORITHM = "AES"; 
	private static final byte[] SALT = "headsupheadsuphe".getBytes();
	
	static Key getSalt() {
		return new SecretKeySpec(SALT, ALGORITHM);
	}
	static String getEncrypted(String plainText) {
		if(plainText == null) {
			return null; 
			
		}
		
		Key salt = getSalt();
		try {
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.ENCRYPT_MODE, salt);
			byte[] encodedValue = cipher.doFinal(plainText.getBytes());
			return Base64.getEncoder().encodeToString(encodedValue); 
			
		}catch (Exception e) {
			e.printStackTrace(); 
			
		}
		throw new IllegalArgumentException("Could not encrypt password"); 
	}
	
	public static String getDecrypted(String encodedText) {
		if (encodedText == null) {
			return null; 
		}
		Key salt = getSalt(); 
		
		try {
			Cipher cipher = Cipher.getInstance(ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE, salt);
			byte[] decodedValue = Base64.getDecoder().decode(encodedText);
			byte[] decValue = cipher.doFinal(decodedValue); 
			return new String(decValue); 
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null; 
	}
	
}
