package headsup;

import java.awt.Font;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.Desktop;
import java.net.URI;
import java.net.URISyntaxException;

public class SystrayIcon {
	
	static TrayIcon trayIcon;
	private AlertJFrame aj = null; 
	public SystrayIcon() {
		show();
	}
	public SystrayIcon(AlertJFrame alertJFrame) {
		this.aj = alertJFrame; 
		show(); 
	}
	private void show() {
		if(!SystemTray.isSupported()) {
			System.out.println("Your Computer DOesn't support Systray Icons");
			System.exit(0);
			
		}
		trayIcon = new TrayIcon(createIcon("/headsup/headsupIcon.png","Icon")); 
		trayIcon.setToolTip("HeadsUp Silent Alert System");
		final SystemTray tray = SystemTray.getSystemTray();
		final PopupMenu menu = new PopupMenu(); 
		MenuItem alarm = new MenuItem("Send Alarm"); 
		menu.add(alarm);
		alarm.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
				    try {
						Desktop.getDesktop().browse(new URI("http://" + aj.getIP() + "/sendalarm.php?pw=" + aj.getPW().trim() + "&username=" + aj.getUser().trim() + "&source=" + aj.getComputer().trim()));
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (URISyntaxException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
			}
			
		});
		menu.addSeparator();
		
		MenuItem settings = new MenuItem("Settings"); 
		menu.add(settings); 
		settings.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				//JOptionPane.showMessageDialog(null, "Not sure what this does! ");
			//	aj.setVisible(true);
				SettingsJFrame settings = new SettingsJFrame(aj); 
				settings.setVisible(true);
				
	
			}
			
		});
		
	
		menu.addSeparator();
		
		MenuItem exit = new MenuItem("Exit"); 
		menu.add(exit);
		
		exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
			
		});
		
		
		
		trayIcon.setPopupMenu(menu);
		
		try {
			tray.add(trayIcon);
		}catch (Exception e) {
			
		}
		
	}
	
	protected static Image createIcon(String path, String desc) {
		URL imageURL = SystrayIcon.class.getResource(path);
		
		return (new ImageIcon(imageURL, desc).getImage());
		
	}
}
