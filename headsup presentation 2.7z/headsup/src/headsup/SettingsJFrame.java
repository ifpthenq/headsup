package headsup;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class SettingsJFrame extends JFrame {

	private JPanel contentPane;
	private AlertJFrame aj;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//SettingsJFrame frame = new SettingsJFrame();
					//frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SettingsJFrame(AlertJFrame aj) {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		contentPane = new JPanel();
		
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setBounds(400, 400, 254, 452);
		//Settings Top Label
		
		JLabel lblSettings = new JLabel("Settings");
		lblSettings.setBounds(10, 11, 230, 29);
		lblSettings.setHorizontalAlignment(SwingConstants.CENTER);
		lblSettings.setFont(new Font("Tahoma", Font.BOLD, 16));
		contentPane.add(lblSettings);
		
		//ip address field
		JTextField textField = new JTextField();
		textField.setBounds(10, 51, 210, 20);
		textField.setText(aj.getIP());
		textField.setColumns(10);
		contentPane.add(textField);
		
		JLabel lblServerIpAddress = new JLabel("Server IP Address");
		lblServerIpAddress.setBounds(10, 72, 190, 14);
		contentPane.add(lblServerIpAddress);
		
		//username field
		JTextField textField2 = new JTextField();
		textField2.setBounds(10, 146, 210, 20);
		textField2.setText(aj.getUser());
		contentPane.add(textField2);
		textField2.setColumns(10);
		
		JLabel lblPasswordToConnect = new JLabel("Username");
		lblPasswordToConnect.setBounds(9, 166, 210, 14);
		contentPane.add(lblPasswordToConnect);
		
		//password
		JTextField textField3 = new JTextField();
		textField3.setColumns(10);
		textField3.setText(aj.getPW());
		textField3.setBounds(9, 197, 210, 20);
		contentPane.add(textField3);
		//computer name
		JTextField textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(10, 96, 210, 20);
		textField_2.setText(aj.getComputer());
		contentPane.add(textField_2);
		setVisible(true);
		
		JButton btnSaveSettings = new JButton("Save");
		btnSaveSettings.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String textFieldValue = textField.getText();
				aj.setIP(textFieldValue);
				String username = textField2.getText();
				aj.setUser(username); 
				String password = textField3.getText();
				String encryptedpw = aj.encryptPassword(password); 
				aj.setPW(password);
				String thisComputer = textField_2.getText(); 
				aj.setComputer(thisComputer);
				
				aj.writeConfigFile();
				
			}
		});
		btnSaveSettings.setBounds(9, 237, 89, 23);
		contentPane.add(btnSaveSettings);
		
		JLabel lblPinger = new JLabel("<html>Test Connection</html>");
		lblPinger.setBounds(10, 290, 210, 89);
		contentPane.add(lblPinger);
		
		JButton btnTest = new JButton("Test");
		btnTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					String textFieldValue = textField.getText();
					aj.setIP(textFieldValue);
					String username = textField2.getText();
					aj.setUser(username); 
					String password = textField3.getText();
					String encryptedpw = aj.encryptPassword(password); 
					aj.setPW(password);
					String thisComputer = textField_2.getText(); 
					aj.setComputer(thisComputer);
					
					aj.writeConfigFile();
					String testresult = aj.testConnection();
					if(testresult.equals("true")) {
						lblPinger.setText("Connection Successful");
						repaint();
					}else {
						lblPinger.setText("Bad Username or Password");
						repaint();
					}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					lblPinger.setText("Invalid character used");
					repaint();
				}catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					lblPinger.setText("Problem connecting to server");
					repaint();
				}
			}
		});
		btnTest.setBounds(120, 237, 89, 23);
		contentPane.add(btnTest);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(1, 279, 290, 10);     
		contentPane.add(separator);
		
		
		//lblPinger.setText("");
		
		
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(10, 217, 210, 14);
		contentPane.add(lblPassword);
		
		JLabel lblComputerLocation = new JLabel("Computer Location");
		lblComputerLocation.setBounds(10, 116, 210, 14);
		contentPane.add(lblComputerLocation);
		
		
		
		//aj.launchSettings();
		
	}

}
